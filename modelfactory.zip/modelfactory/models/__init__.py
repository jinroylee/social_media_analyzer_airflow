"""
Models package for social media engagement prediction.
""" 